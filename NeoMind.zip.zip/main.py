import requests
import os
from dotenv import load_dotenv
import telebot

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

if not all([TELEGRAM_BOT_TOKEN, OPENROUTER_API_KEY]):
    raise ValueError("Please set TELEGRAM_BOT_TOKEN and OPENROUTER_API_KEY in secrets")

bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)

def list_models():
    url = f"https://generativelanguage.googleapis.com/v1/models?key={os.getenv('GEMINI_API_KEY')}" 
    response = requests.get(url)
    return response.json()

def ask_gemini(prompt):
    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {os.getenv('OPENROUTER_API_KEY')}",
        "Content-Type": "application/json"
    }

    body = {
        "model": "google/gemini-pro",
        "messages": [
            {"role": "system", "content": "You are NeoMind, an intelligent and friendly assistant. Answer clearly, accurately, and helpfully in simple language."},
            {"role": "user", "content": prompt}
        ]
    }

    response = requests.post(url, headers=headers, json=body)
    result = response.json()

    try:
        return result['choices'][0]['message']['content']
    except Exception as e:
        print("OpenRouter Error:", result)
        return "Sorry, I couldn't generate a response right now."

from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_chat_action(message.chat.id, 'typing')

    # Create buttons
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(
        InlineKeyboardButton("Ask a Question", callback_data="ask"),
        InlineKeyboardButton("About NeoMind", callback_data="about"),
        InlineKeyboardButton("Help", callback_data="help")
    )

    bot.reply_to(
        message,
        "Hey *{0}*! I'm *NeoMind*, your AI assistant.\n\nChoose an option below or just type your question.".format(message.from_user.first_name),
        parse_mode='Markdown',
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "ask":
        bot.send_message(call.message.chat.id, "Go ahead, ask me anything!")
    elif call.data == "about":
        bot.send_message(call.message.chat.id, "NeoMind is a smart AI bot built by Saurav using Gemini. I can help you with studies, ideas, tech, finance & more.")
    elif call.data == "help":
        bot.send_message(call.message.chat.id, "Type your question directly, or use the buttons to interact with me.")

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    prompt = message.text
    reply = ask_gemini(prompt)
    bot.reply_to(message, reply)

print("Bot is polling...")
bot.infinity_polling()